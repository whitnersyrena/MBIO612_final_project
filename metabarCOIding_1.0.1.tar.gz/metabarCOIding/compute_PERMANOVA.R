#' compute PERMANVOA function
#'
#'
#' @export

compute_PERMANOVA <- function (ASV_df, grouping_factor, data_df, method_distance) {

  factor = data_df[,grouping_factor]

  PERMANOVA <- adonis (ASV_df ~ factor, data= data_df, permutations = 9999, method = {{method_distance}}, na.rm=T)

  return (PERMANOVA)
}
