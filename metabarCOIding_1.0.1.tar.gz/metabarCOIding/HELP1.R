#' metabarCOIding package
#'
#'  This package includes univariate and multivariate analysis of community composition to analyse metabarcoding community data.
#'  Overall, functions included in this package aim to examine the overall diversity of most abundant taxa in the community, to
#'  examine the Beta Diversity and the Variation in community structure based on different grouping factors and to investigate the OTUs/ASVs that can be used as indicators of different factors.
#'
#'
#' @docType package
#'
#' @author Gabrielle Martineau email \\ {mg62@hawaii.edu}
#'
#'
#' @name metabarCOIding
#'
#' @import packagename
NULL
