#' Merge data tables into single table
#'
#'
#'
#'
#'
#'
#'
#' @export



merge_full_table <- function (taxonomy_DNA, ASV_table_DNA) {

  #Merge Taxonomy and ASV tables into a new object
  combined_table <- join(taxonomy_DNA, ASV_table_DNA)
  rownames(combined_table) <- rownames(ASV_table_DNA)


  #delete useless ID_ASV column for taxonxomy and ASV tables
  ASV_table_DNA$ID_ASV <- NULL
  taxonomy_DNA$ID_ASV <- NULL
  combined_table$ID_ASV <- NULL

  assign("combined_table", combined_table, envir = .GlobalEnv)

}
