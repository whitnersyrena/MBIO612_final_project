#' plot
#'
#'
#' @export

plot_taxonomic_barplot <- function (barplot_data_df, color_palette, taxa_name, factor) {

  taxonomic_barplot <-ggplot(barplot_data_df, aes (fill = reorder(.data[[taxa_name]], mean_abundance_ASV_group), y= mean_abundance_ASV_group, x= .data[[factor]]))+

    geom_bar (position="fill",  stat= "identity") + theme_bw() +

    scale_fill_manual(values=color_palette)

  taxonomic_barplot

}
